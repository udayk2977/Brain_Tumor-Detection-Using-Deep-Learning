import os
import glob
import numpy as np

# root of your split data
BASE_DIR = "BraTS2020_TrainingData/input_data_128"
for split in ("train", "val"):
    img_in_dir  = os.path.join(BASE_DIR, split, "images")
    msk_in_dir  = os.path.join(BASE_DIR, split, "masks")
    img_out_dir = os.path.join(BASE_DIR, split, "images_slicewise")
    msk_out_dir = os.path.join(BASE_DIR, split, "masks_slicewise")
    
    os.makedirs(img_out_dir, exist_ok=True)
    os.makedirs(msk_out_dir, exist_ok=True)
    
    # find all volumes
    img_paths = sorted(glob.glob(os.path.join(img_in_dir, "*.npy")))
    for img_path in img_paths:
        fname = os.path.splitext(os.path.basename(img_path))[0]   # e.g. "image_0"
        msk_path = os.path.join(msk_in_dir, fname.replace("image_", "mask_") + ".npy")
        if not os.path.isfile(msk_path):
            print(f"Warning: mask not found for {fname}, skipping")
            continue
        
        # load volumes
        vol  = np.load(img_path)   # shape e.g. (128,128,128,3)
        mask = np.load(msk_path)   # shape e.g. (128,128,128,4)
        
        # make output subdirs
        img_sub = os.path.join(img_out_dir, fname)
        msk_sub = os.path.join(msk_out_dir, fname)
        os.makedirs(img_sub, exist_ok=True)
        os.makedirs(msk_sub, exist_ok=True)
        
        # slice and save
        num_slices = vol.shape[2]
        for z in range(num_slices):
            slice_img  = vol[:, :, z, ...]    # (H,W,3)
            slice_msk  = mask[:, :, z, ...]   # (H,W,4)
            np.save(os.path.join(img_sub, f"slice_{z:03d}.npy"), slice_img)
            np.save(os.path.join(msk_sub, f"slice_{z:03d}.npy"), slice_msk)
        
        print(f"Split {fname} into {num_slices} 2D slices [{split}]")
